export type Role = 'admin' | 'pro' | 'client';

export interface User {
  id: string;
  email: string;
  role: Role;
  name: string;
}

export interface Service {
  id: string;
  title: string;
  duration: number;
  price: number;
  options?: ServiceOption[];
  proId: string;
}

export interface ServiceOption {
  id: string;
  title: string;
  price: number;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
}

export interface ServiceGroup {
  id: string;
  name: string;
  services: string[]; // Service IDs
  proId: string;
}